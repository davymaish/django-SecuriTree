

Models 

    Areas 
        "id": "6C4E2C5D-BBBB-4386-AA71-B7F56727433C",
        "name": "Wonka Factory",
        "parent_area_id": null
        "child_area_ids": ->arrays

    Doors
        "id": "126A73D3-2148-4DA9-9332-867571884AA1",
        "name": "Main Gate",
        "parent_area": "6C4E2C5D-BBBB-4386-AA71-B7F56727433C",
        "status": "open"

    Access rules
        "id": "186DD659-EC26-4AA2-8389-706E58284171",
        "name": "sar-admin-oompas",
        doors ->arrays

    User
        "username": "knopel",
        "first_name": "Leslie",
        "surname": "Knope",
        "password": "jjsdiner"

Relationships
    Many Doors to one Area
    Many Access Rules to Many Doors
    Many Access Rules to Many Users
    Many Access Rules to Many Areas Through Doors

Logic
    An intermediate table for doors and access rules
    An intermediate table for users and access rules

Functionality
    If a door is unlocked, anyone can use the door. If it is locked, only people in the door’s list of access rules are allowed to use the door
    In the provided examples and screens, only the door name appears on the entity hierarchy. You will therefore either have to display the door id on the entity hierarchy or allow the user to search for a door id using the door name.
    Your application does NOT have to provide functionality to register new users in your access management system.


Populate Database
    python3 manage.py populateUserData SecuriTree/fixtures/registered_users.json
    python3 manage.py populateSystemData SecuriTree/fixtures/system_data.json

ACCESS HEEIRACHY DUPLICACY
back button


visual programming language
html and css

application logic programming language
Python

User Interface
Web Page Interface

Application Web Framework
Django