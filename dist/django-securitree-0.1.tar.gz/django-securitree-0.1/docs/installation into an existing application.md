Installation In an Existing Django Application
-----------

1. Add "SecuriTree" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'SecuriTree',
    ]

2. Include the polls URLconf in your project urls.py like this::

    path('securitree/', include('SecuriTree.urls')),

3. Run ``python manage.py migrate`` to create the SecuriTree models.

4. Populate Database
    ``
    python3 manage.py populateUserData SecuriTree/fixtures/registered_users.json
    python3 manage.py populateSystemData SecuriTree/fixtures/system_data.json
    ``

5. Visit http://127.0.0.1:8000/securitree/ to participate in the poll.